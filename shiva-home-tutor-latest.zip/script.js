/* Shiva Home Tutor — shared site script
   Handles: mobile menu, enquiry form, tutor form, teacher-application form,
   Google Sheet submission, the teacher enquiry board, stat-counter animation.
   Loaded on every page; each block checks its own elements exist before running. */

// ⚠️ Your deployed Google Apps Script Web App URL (see google-sheet-setup-code.gs)
const SHEET_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxTSSd7MRnkqpbnH31WJJuBIxlFf-EqcJFOOfIq4zLHVynwDS7LStrDbj3wyCtWsZ9Hng/exec";

const WHATSAPP_NUMBER = "918766379988";
const CONTACT_EMAIL = "shivahometutor.apply@gmail.com";
const MAX_UPLOAD_BYTES = 5 * 1024 * 1024; // 5MB

function sendToSheet(payload) {
  if (!SHEET_SCRIPT_URL || SHEET_SCRIPT_URL.indexOf("PASTE_YOUR") === 0) {
    console.warn("Google Sheet URL not set yet — skipping sheet save.");
    return Promise.resolve();
  }
  return fetch(SHEET_SCRIPT_URL, {
    method: "POST",
    mode: "no-cors",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify(payload)
  }).catch(function (err) { console.error("Sheet save failed:", err); });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

function fileToBase64(file) {
  return new Promise(function (resolve, reject) {
    if (!file) { resolve(null); return; }
    if (file.size > MAX_UPLOAD_BYTES) { reject(new Error(file.name + " is over 5MB")); return; }
    const reader = new FileReader();
    reader.onload = function () { resolve(reader.result); };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

/* ============ Teacher enquiry board (teacher-enquiries.html) ============ */

function statusBadgeClass(status) {
  const s = (status || "").toLowerCase();
  if (s === "open") return "background:#2FA84F; color:#fff;";
  if (s === "shortlisting") return "background:var(--marigold); color:#2A2000;";
  if (s === "teacher selected") return "background:#4B6FE0; color:#fff;";
  return "background:#9AA39C; color:#fff;"; // closed / unknown
}

function loadOpenEnquiries(container) {
  if (!SHEET_SCRIPT_URL || SHEET_SCRIPT_URL.indexOf("PASTE_YOUR") === 0) {
    container.innerHTML = '<p class="form-note">Enquiry board isn\'t connected yet.</p>';
    return;
  }
  container.innerHTML = '<p class="form-note">Loading current requirements…</p>';

  fetch(SHEET_SCRIPT_URL)
    .then(function (res) { return res.json(); })
    .then(function (data) {
      const enquiries = data.enquiries || [];
      if (!enquiries.length) {
        container.innerHTML = '<p class="form-note">No tuition requirements posted right now — check back soon.</p>';
        return;
      }
      container.innerHTML = "";
      enquiries.forEach(function (enq) {
        const isOpen = (enq.status || "").toLowerCase() === "open";
        const summary = [enq.class, enq.subject, enq.location].filter(Boolean).join(" — ");
        const detailsParam = encodeURIComponent(summary);

        const card = document.createElement("div");
        card.className = "card enquiry-card";
        card.innerHTML =
          '<div class="num">' + escapeHtml(enq.id) +
            ' <span style="float:right; font-size:0.7rem; padding:3px 9px; border-radius:12px; font-family:var(--font-mono); ' + statusBadgeClass(enq.status) + '">' + escapeHtml(enq.status || "Open") + '</span>' +
          '</div>' +
          '<h3>' + escapeHtml(enq.subject || "Tutor needed") + ' — ' + escapeHtml(enq.class || "") + '</h3>' +
          '<p>📍 ' + escapeHtml(enq.location || "Area not specified") + (enq.gender ? ' · ' + escapeHtml(enq.gender) : '') + '</p>' +
          '<p>' + escapeHtml(enq.mode || "") + (enq.days ? ' · ' + escapeHtml(enq.days) : '') + (enq.timing ? ' · ' + escapeHtml(enq.timing) : '') + '</p>' +
          (enq.fees ? '<p><strong>' + escapeHtml(enq.fees) + '</strong>' + (enq.board ? ' · ' + escapeHtml(enq.board) : '') + '</p>' : (enq.board ? '<p>' + escapeHtml(enq.board) + '</p>' : '')) +
          (enq.requirements ? '<p>' + escapeHtml(enq.requirements) + '</p>' : '') +
          (enq.posted ? '<p class="blog-keywords">Posted: ' + escapeHtml(enq.posted) + '</p>' : '') +
          (isOpen
            ? '<button type="button" class="btn btn-red btn-block apply-btn" style="margin-top:10px;" data-id="' + escapeHtml(enq.id) + '" data-summary="' + detailsParam + '">Apply for This Enquiry</button>'
            : '<button type="button" class="btn btn-outline-dark btn-block" style="margin-top:10px;" disabled>Applications Closed</button>');
        container.appendChild(card);
      });

      container.querySelectorAll(".apply-btn").forEach(function (btn) {
        btn.addEventListener("click", function () {
          openApplicationForm(btn.getAttribute("data-id"), decodeURIComponent(btn.getAttribute("data-summary")));
        });
      });
    })
    .catch(function (err) {
      console.error("Failed to load enquiries:", err);
      container.innerHTML = '<p class="form-note">Couldn\'t load current requirements right now. Please try again shortly, or message us on WhatsApp.</p>';
    });
}

function openApplicationForm(enquiryId, enquirySummary) {
  const panel = document.getElementById("application-form-panel");
  const placeholder = document.getElementById("apply-placeholder");
  const banner = document.getElementById("applyingToBanner");
  if (!panel) return;
  panel.style.display = "block";
  if (placeholder) placeholder.style.display = "none";
  if (banner) banner.textContent = "Applying for: " + enquirySummary + " (Enquiry ID: " + enquiryId + ")";
  panel.dataset.enquiryId = enquiryId;
  panel.dataset.enquirySummary = enquirySummary;
  panel.scrollIntoView({ behavior: "smooth", block: "start" });
}

/* ============ DOM ready: wire up everything that exists on this page ============ */

document.addEventListener("DOMContentLoaded", function () {
  /* ---------- Mobile menu ---------- */
  const toggle = document.querySelector(".menu-toggle");
  const menu = document.querySelector(".mobile-menu");
  if (toggle && menu) {
    toggle.addEventListener("click", function () {
      const isOpen = menu.classList.toggle("open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    menu.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        menu.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* ---------- Parent enquiry form ---------- */
  const enquiryForm = document.getElementById("enquiryForm");
  if (enquiryForm) {
    enquiryForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const name = document.getElementById("p-name").value;
      const mobile = document.getElementById("p-mobile").value;
      const cls = document.getElementById("p-class").value;
      const subject = document.getElementById("p-subject").value;
      const area = document.getElementById("p-area").value;
      const time = document.getElementById("p-time").value;
      const msg = "Hi, I need a tutor.\nName: " + name + "\nMobile: " + mobile +
        "\nClass: " + cls + "\nSubject: " + subject + "\nArea: " + area +
        "\nPreferred timing: " + time;

      sendToSheet({ formType: "parent", name: name, mobile: mobile, class: cls, subject: subject, area: area, timing: time });

      const waBtn = document.getElementById("enquiryWa");
      if (waBtn) waBtn.href = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(msg);
      const successEl = document.getElementById("enquirySuccess");
      if (successEl) successEl.classList.add("show");
      enquiryForm.style.display = "none";
    });
  }

  /* ---------- Simple "Become a Tutor" form (homepage) ---------- */
  const tutorForm = document.getElementById("tutorForm");
  if (tutorForm) {
    tutorForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const name = document.getElementById("t-name").value;
      const mobile = document.getElementById("t-mobile").value;
      const qual = document.getElementById("t-qual").value;
      const exp = document.getElementById("t-exp").value;
      const subjects = document.getElementById("t-subjects").value;
      const classes = document.getElementById("t-classes").value;
      const area = document.getElementById("t-area").value;
      const mode = document.getElementById("t-mode").value;
      const msg = "Hi, I want to register as a tutor.\nName: " + name + "\nMobile: " + mobile +
        "\nQualification: " + qual + "\nExperience: " + exp + "\nSubjects: " + subjects +
        "\nClasses: " + classes + "\nPreferred Area: " + area + "\nMode: " + mode;

      sendToSheet({ formType: "tutor", name: name, mobile: mobile, qualification: qual, experience: exp, subjects: subjects, classes: classes, area: area, mode: mode });

      const waBtn = document.getElementById("tutorWa");
      if (waBtn) waBtn.href = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(msg);
      const emailBtn = document.getElementById("tutorEmail");
      if (emailBtn) {
        emailBtn.href = "mailto:" + CONTACT_EMAIL + "?subject=" + encodeURIComponent("Tutor Registration - " + name) +
          "&body=" + encodeURIComponent(msg + "\n\n(Please attach your resume and photo to this email)");
      }
      const successEl = document.getElementById("tutorSuccess");
      if (successEl) successEl.classList.add("show");
      tutorForm.style.display = "none";
    });
  }

  /* ---------- Teacher enquiry board + dedicated application form ---------- */
  const enquiryListEl = document.getElementById("enquiry-list");
  if (enquiryListEl) {
    loadOpenEnquiries(enquiryListEl);
  }

  const applicationForm = document.getElementById("teacherApplicationForm");
  if (applicationForm) {
    applicationForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const panel = document.getElementById("application-form-panel");
      const submitBtn = document.getElementById("applySubmitBtn");
      const uploadNote = document.getElementById("uploadStatusNote");
      const enquiryId = (panel && panel.dataset.enquiryId) || "";
      const enquirySummary = (panel && panel.dataset.enquirySummary) || "";

      const resumeFile = document.getElementById("a-resume").files[0];
      const photoFile = document.getElementById("a-photo").files[0];

      submitBtn.disabled = true;
      submitBtn.textContent = "Submitting…";
      if (uploadNote) uploadNote.textContent = "";

      Promise.all([fileToBase64(resumeFile), fileToBase64(photoFile)])
        .then(function (results) {
          const resumeBase64 = results[0];
          const photoBase64 = results[1];

          const payload = {
            formType: "teacherApplication",
            enquiryId: enquiryId,
            enquirySummary: enquirySummary,
            name: document.getElementById("a-name").value,
            whatsapp: document.getElementById("a-whatsapp").value,
            email: document.getElementById("a-email").value,
            gender: document.getElementById("a-gender").value,
            qualification: document.getElementById("a-qual").value,
            experience: document.getElementById("a-exp").value,
            subjects: document.getElementById("a-subjects").value,
            classes: document.getElementById("a-classes").value,
            boards: document.getElementById("a-boards").value,
            currentLocation: document.getElementById("a-location").value,
            preferredAreas: document.getElementById("a-preferred-areas").value,
            mode: document.getElementById("a-mode").value,
            availableDays: document.getElementById("a-days").value,
            availableTime: document.getElementById("a-time").value,
            expectedFees: document.getElementById("a-fees").value,
            introduction: document.getElementById("a-intro").value,
            resumeName: resumeFile ? resumeFile.name : "",
            resumeMimeType: resumeFile ? resumeFile.type : "",
            resumeBase64: resumeBase64 || "",
            photoName: photoFile ? photoFile.name : "",
            photoMimeType: photoFile ? photoFile.type : "",
            photoBase64: photoBase64 || ""
          };

          return sendToSheet(payload);
        })
        .then(function () {
          applicationForm.style.display = "none";
          const successEl = document.getElementById("applicationSuccess");
          if (successEl) successEl.classList.add("show");
        })
        .catch(function (err) {
          console.error("Application submission issue:", err);
          submitBtn.disabled = false;
          submitBtn.textContent = "Submit Application";
          if (uploadNote) uploadNote.textContent = "One of your files may be too large (max 5MB each). Please check and try again, or submit without attachments.";
        });
    });
  }

  /* ---------- Stat counter animation ---------- */
  const statEls = document.querySelectorAll(".stat-num[data-count-to]");
  if (statEls.length && "IntersectionObserver" in window) {
    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const target = parseInt(el.getAttribute("data-count-to"), 10) || 0;
        const suffix = el.getAttribute("data-suffix") || "";
        let current = 0;
        const step = Math.max(1, Math.round(target / 40));
        const timer = setInterval(function () {
          current += step;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 30);
        observer.unobserve(el);
      });
    }, { threshold: 0.4 });
    statEls.forEach(function (el) { observer.observe(el); });
  }
});
