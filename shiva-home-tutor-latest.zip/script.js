/* Shiva Home Tutor — shared site script
   Handles: mobile menu, enquiry form, tutor form, Google Sheet submission,
   stat-counter animation. Loaded on every page. */

// ⚠️ Your deployed Google Apps Script Web App URL (see google-sheet-setup-code.gs)
const SHEET_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxTSSd7MRnkqpbnH31WJJuBIxlFf-EqcJFOOfIq4zLHVynwDS7LStrDbj3wyCtWsZ9Hng/exec";

const WHATSAPP_NUMBER = "918766379988";
const CONTACT_EMAIL = "shivahometutor.apply@gmail.com";

function sendToSheet(payload) {
  if (!SHEET_SCRIPT_URL || SHEET_SCRIPT_URL.indexOf("PASTE_YOUR") === 0) {
    console.warn("Google Sheet URL not set yet — skipping sheet save.");
    return Promise.resolve();
  }
  return fetch(SHEET_SCRIPT_URL, {
    method: "POST",
    mode: "no-cors",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify(payload)
  }).catch(function (err) { console.error("Sheet save failed:", err); });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

function loadOpenEnquiries(container) {
  if (!SHEET_SCRIPT_URL || SHEET_SCRIPT_URL.indexOf("PASTE_YOUR") === 0) {
    container.innerHTML = '<p class="form-note">Enquiry board isn\'t connected yet.</p>';
    return;
  }
  container.innerHTML = '<p class="form-note">Loading current requirements…</p>';

  fetch(SHEET_SCRIPT_URL)
    .then(function (res) { return res.json(); })
    .then(function (data) {
      const enquiries = data.enquiries || [];
      if (!enquiries.length) {
        container.innerHTML = '<p class="form-note">No open requirements right now — check back soon, or message us on WhatsApp to ask directly.</p>';
        return;
      }
      container.innerHTML = "";
      enquiries.forEach(function (enq) {
        const card = document.createElement("div");
        card.className = "card enquiry-card";
        const summary = [enq.class, enq.subject, enq.area].filter(Boolean).join(" — ");
        const detailsParam = encodeURIComponent(summary + (enq.notes ? " (" + enq.notes + ")" : ""));
        card.innerHTML =
          '<div class="num">' + escapeHtml(enq.id) + '</div>' +
          '<h3>' + escapeHtml(enq.subject || "Tutor needed") + ' — ' + escapeHtml(enq.class || "") + '</h3>' +
          '<p>📍 ' + escapeHtml(enq.area || "Area not specified") + '</p>' +
          (enq.notes ? '<p>' + escapeHtml(enq.notes) + '</p>' : '') +
          '<a class="btn btn-red" style="margin-top:10px;" href="index.html?enquiry=' + encodeURIComponent(enq.id) + '&details=' + detailsParam + '#become-tutor">I\'m Interested</a>';
        container.appendChild(card);
      });
    })
    .catch(function (err) {
      console.error("Failed to load enquiries:", err);
      container.innerHTML = '<p class="form-note">Couldn\'t load current requirements right now. Please try again shortly, or message us on WhatsApp.</p>';
    });
}

/* ---------- Mobile menu ---------- */
document.addEventListener("DOMContentLoaded", function () {
  const toggle = document.querySelector(".menu-toggle");
  const menu = document.querySelector(".mobile-menu");
  if (toggle && menu) {
    toggle.addEventListener("click", function () {
      const isOpen = menu.classList.toggle("open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    menu.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        menu.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* ---------- Parent enquiry form ---------- */
  const enquiryForm = document.getElementById("enquiryForm");
  if (enquiryForm) {
    enquiryForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const name = document.getElementById("p-name").value;
      const mobile = document.getElementById("p-mobile").value;
      const cls = document.getElementById("p-class").value;
      const subject = document.getElementById("p-subject").value;
      const area = document.getElementById("p-area").value;
      const time = document.getElementById("p-time").value;
      const msg = "Hi, I need a tutor.\nName: " + name + "\nMobile: " + mobile +
        "\nClass: " + cls + "\nSubject: " + subject + "\nArea: " + area +
        "\nPreferred timing: " + time;

      sendToSheet({
        formType: "parent",
        name: name, mobile: mobile, class: cls, subject: subject, area: area, timing: time
      });

      const waBtn = document.getElementById("enquiryWa");
      if (waBtn) waBtn.href = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(msg);
      const successEl = document.getElementById("enquirySuccess");
      if (successEl) successEl.classList.add("show");
      enquiryForm.style.display = "none";
    });
  }

  /* ---------- Tutor registration form ---------- */
  const tutorForm = document.getElementById("tutorForm");

  // If the tutor arrived via an "I'm Interested" button on the job board,
  // show a banner and remember what they're responding to.
  var respondingToText = "";
  const params = new URLSearchParams(window.location.search);
  const enquiryDetails = params.get("details");
  if (enquiryDetails) {
    respondingToText = enquiryDetails;
    const banner = document.getElementById("respondingToBanner");
    if (banner) {
      banner.textContent = "You're responding to: " + enquiryDetails;
      banner.classList.add("show");
    }
  }

  if (tutorForm) {
    tutorForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const name = document.getElementById("t-name").value;
      const mobile = document.getElementById("t-mobile").value;
      const qual = document.getElementById("t-qual").value;
      const exp = document.getElementById("t-exp").value;
      const subjects = document.getElementById("t-subjects").value;
      const classes = document.getElementById("t-classes").value;
      const area = document.getElementById("t-area").value;
      const mode = document.getElementById("t-mode").value;
      let msg = "Hi, I want to register as a tutor.\nName: " + name + "\nMobile: " + mobile +
        "\nQualification: " + qual + "\nExperience: " + exp + "\nSubjects: " + subjects +
        "\nClasses: " + classes + "\nPreferred Area: " + area + "\nMode: " + mode;
      if (respondingToText) {
        msg += "\n\nResponding to posted enquiry: " + respondingToText;
      }

      sendToSheet({
        formType: "tutor",
        name: name, mobile: mobile, qualification: qual, experience: exp,
        subjects: subjects, classes: classes, area: area, mode: mode,
        respondingTo: respondingToText
      });

      const waBtn = document.getElementById("tutorWa");
      if (waBtn) waBtn.href = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(msg);
      const emailBtn = document.getElementById("tutorEmail");
      if (emailBtn) {
        emailBtn.href = "mailto:" + CONTACT_EMAIL + "?subject=" + encodeURIComponent("Tutor Registration - " + name) +
          "&body=" + encodeURIComponent(msg + "\n\n(Please attach your resume and photo to this email)");
      }
      const successEl = document.getElementById("tutorSuccess");
      if (successEl) successEl.classList.add("show");
      tutorForm.style.display = "none";
    });
  }

  /* ---------- Open Enquiries job board ---------- */
  const enquiryListEl = document.getElementById("enquiry-list");
  if (enquiryListEl) {
    loadOpenEnquiries(enquiryListEl);
  }


  /* ---------- Stat counter animation ---------- */
  const statEls = document.querySelectorAll(".stat-num[data-count-to]");
  if (statEls.length && "IntersectionObserver" in window) {
    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const target = parseInt(el.getAttribute("data-count-to"), 10) || 0;
        const suffix = el.getAttribute("data-suffix") || "";
        let current = 0;
        const step = Math.max(1, Math.round(target / 40));
        const timer = setInterval(function () {
          current += step;
          if (current >= target) {
            current = target;
            clearInterval(timer);
          }
          el.textContent = current + suffix;
        }, 30);
        observer.unobserve(el);
      });
    }, { threshold: 0.4 });
    statEls.forEach(function (el) { observer.observe(el); });
  }
});
